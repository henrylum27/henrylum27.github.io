import { mkdir, copyFile } from 'node:fs/promises';
for (const id of ['binarymed','data-analyst-agent']) {
  await mkdir(`dist/projects/${id}`,{recursive:true});
  await copyFile('dist/index.html',`dist/projects/${id}/index.html`);
}
await copyFile('dist/index.html','dist/404.html');
