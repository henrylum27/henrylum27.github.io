Add the real resume PDF or project screenshots here. See the root README.md for expected filenames.
