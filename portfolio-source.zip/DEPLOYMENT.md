# Deploy the portfolio

This is a static Vite application. Commit source and lockfile; exclude `node_modules` and `dist`. Remove `.openai/hosting.json` when copying this project for an unrelated Sites registration; retain it when updating this Site.

## Cloudflare Pages

Connect a Git repository in Pages and choose:

- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: the portfolio project directory

`public/_redirects` is copied to `dist` to serve React routes. You can also upload the built `dist` directory directly. Check `/projects/binarymed` by opening the URL directly after deploying.

## Vercel

Import the repository, select Vite, use `npm run build` and `dist`. The included `vercel.json` rewrites project routes to the application. No server or secrets are required.

## GitHub Pages

For a user site named `henrylum27.github.io`, leave the Vite base at `/`. For a project site named `portfolio`, set `VITE_BASE_PATH=/portfolio/` during the build. Vite uses this prefix for assets, navigation and screenshots.

An Actions workflow should check out the repository, set up Node 22, run `npm ci`, run `npm run build` with the correct base, upload `dist` using `actions/upload-pages-artifact`, and deploy using `actions/deploy-pages`. Set Pages source to GitHub Actions and grant `contents: read`, `pages: write`, `id-token: write` permissions.

The build script copies `index.html` into each project route directory, so direct navigation works on GitHub Pages without custom rewrites. A `404.html` copy is also generated. Keep the route export list in `scripts/export-routes.mjs` up to date when adding projects. Visit both the homepage and direct case-study URLs to verify the deployment.

## Before linking from a resume

Add the actual resume and real screenshots. Replace the social image with a PNG and update its absolute URL to your chosen hosting domain. Confirm repository URLs and remaining contribution details. Sites publishing begins private; make the audience public when you are ready for recruiters to visit.

Official guides: [Cloudflare Pages](https://developers.cloudflare.com/pages/framework-guides/deploy-a-vite3-project/), [Vite static hosting and GitHub Pages](https://vite.dev/guide/static-deploy.html), [Vercel Vite](https://vercel.com/docs/frameworks/frontend/vite).

