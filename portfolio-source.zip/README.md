# Henry Lum — AI & Software Engineer

A recruiter-friendly, static portfolio built with React, TypeScript, Vite, Tailwind CSS and Lucide icons. Dark navy panels, restrained cyan accents, a code-inspired hero, responsive layouts and reduced-motion support.

## Run locally

Requires Node.js 20.19+ or a supported newer LTS release.

```sh
npm install
npm run dev
npm run build
npm run preview
```

## Pages

- `/`: hero, about, projects, experience, skills, education, languages and contact.
- `/projects/binarymed`: full case study, architecture, features, role, screenshots and repositories.
- `/projects/data-analyst-agent`: project detail page with clearly marked gaps.

## Update content

Personal links and resume status: `src/data/profile.ts`. Edit project objects in `src/data/projects.ts`, grouped skills in `src/data/skills.ts`, internships in `src/data/experience.ts`, and degree details in `src/data/education.ts`.

To add a project, append an object using the `Project` type, choose a unique id, add screenshot entries and categories, The displayed project count updates automatically. Its detail route is generated automatically. Categories drive the All / AI / Data / Software filters.

Reusable components in `src/components/UI.tsx`: Navbar, Hero, SectionHeading, ProjectCard, FeaturedProject, SkillGroup, ExperienceCard, EducationCard, ContactSection, Footer, Tags, Screenshot, SocialLinks and ResumeButton. Main page and case study templates live in `src/App.tsx`; visual styles in `src/styles.css`.

## Screenshots and resume

Place actual screenshots in `public/projects/` at paths listed in project data. BinaryMed expects `dashboard.png`, `temperature.png`, `path.png`, `report.png` in `public/projects/binarymed/`. Data Analyst Agent expects `analysis.png` in `public/projects/data-analyst-agent/`. Failed image loads display labelled placeholder frames; no fake application images are included.

Add the actual PDF at `public/resume/Henry_Lum_Resume.pdf` and set `resumeAvailable: true` in `src/data/profile.ts`. All resume links already target that path. Until then they show a clear notice instead of downloading a missing file. No phone number is displayed.

## TODO inventory

- Add resume PDF and enable download.
- Replace screenshot placeholders.
- Live demo links are unspecified.
- Verify personal contribution details, challenges and learning outcomes for non-BinaryMed projects.
- The Data Analyst Agent link uses the supplied URL; implementation claims were not expanded from an unverified repository.
- Replace `public/og-placeholder.svg` with a real 1200×630 PNG; update OG and Twitter image tags to an absolute URL. Many social platforms do not support SVG previews.
- Update production origin in `index.html` if deploying elsewhere.

Contact uses `mailto:`; no backend, API keys or form service are needed. See `DEPLOYMENT.md` for free hosting.

## Portfolio chatbot

The floating **Ask about Henry** button opens a portfolio guide on every page. It answers from the current profile, project, skill, education and internship data. Suggested questions help recruiters find key information quickly. Topic matching provides predefined factual answers; this is not a generative AI model or a general-purpose chat service. Unrelated questions and details absent from the portfolio are declined. Messages stay in tab memory and disappear on reload; nothing is sent to a server or stored persistently.

Edit answer matching in `src/data/assistant.ts` and the chat interface in `src/components/PortfolioChat.tsx`. The guide needs no API key, backend or paid service. It inherits project removals and profile-link updates from the portfolio data files.

## Verification in the creation environment

Dependency installation, TypeScript checks and production build passed. Production-preview browser checks covered project filtering, BinaryMed navigation and sections, resume notice, mobile menu, mobile/tablet widths and console errors. The original routes returned HTTP 200; the current build exports only BinaryMed and Data Analyst Agent project routes. The development server was attempted but its esbuild dependency scan was blocked by the workspace filesystem sandbox; production preview worked. Sites source upload was attempted but the Git hosting endpoint could not be reached, so no hosted deployment is claimed.




### Recruiter response rules

Approved availability, relocation, night-shift, salary and AWS-study facts are stored in src/data/recruitment.ts. Expected salary is RM3,500 per month, negotiable with learning opportunities and the overall package in mind. AWS Certified AI Practitioner is in progress, not an earned certification. Skills are checked against portfolio data; unknown requirements receive constructive answers using transferable experience, and project exposure is not upgraded to professional experience. The guide never invents years of experience. Salary follow-ups use the previous turn held in tab memory. Combined availability, relocation and shift questions receive a concise combined answer.

