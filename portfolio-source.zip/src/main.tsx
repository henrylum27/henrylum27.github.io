import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import TracingConsent from './components/TracingConsent';
import './styles.css';
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App/><TracingConsent/></React.StrictMode>);
