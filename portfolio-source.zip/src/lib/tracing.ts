// Public ingestion endpoint only. Database secrets must never appear in VITE variables.
export const tracingEndpoint = (import.meta.env.VITE_TRACING_ENDPOINT || '').trim();
const publicKey=(import.meta.env.VITE_TRACING_PUBLIC_KEY || '').trim();
const consentKey='henry-tracing-consent-v1';
const visitorKey='henry-tracing-visitor-v1';
const sessionKey='henry-tracing-session-v1';
export type TracingConsent='allow'|'decline'|null;
export function getTracingConsent():TracingConsent {
 try {const value=localStorage.getItem(consentKey);return value==='allow'||value==='decline'?value:null;}catch{return null;}
}
export function setTracingConsent(value:'allow'|'decline'){
 try {localStorage.setItem(consentKey,value);if(value==='decline'){localStorage.removeItem(visitorKey);sessionStorage.removeItem(sessionKey);}}catch{/* Storage may be unavailable. Collection stays disabled. */}
 window.dispatchEvent(new Event('tracing-consent'));
}
let pageLogged=false;
let geoPromise:Promise<{country:string|null;city:string|null}>|undefined;
function identifier(storage:Storage,key:string){let value=storage.getItem(key);if(!value){value=crypto.randomUUID();storage.setItem(key,value);}return value;}
function location(){
 // Only requested after consent. Discard IP, coordinates and all other returned fields.
 return geoPromise??=fetch('https://get.geojs.io/v1/ip/geo.json',{signal:AbortSignal.timeout(3000),credentials:'omit',referrerPolicy:'no-referrer'})
  .then(async r=>r.ok?await r.json() as Record<string,unknown>:{} as Record<string,unknown>).then(data=>({country:typeof data.country==='string'?data.country:null,city:typeof data.city==='string'?data.city:null}))
  .catch(()=>({country:null,city:null}));
}
function browser(){const ua=navigator.userAgent;return /Edg\//.test(ua)?'Edge':/OPR\//.test(ua)?'Opera':/Firefox\//.test(ua)?'Firefox':/Chrome\//.test(ua)?'Chrome':/Safari\//.test(ua)?'Safari':'Other';}
function device(){return /iPad|Tablet|Android(?!.*Mobile)/i.test(navigator.userAgent)?'Tablet':/Mobile|iPhone/i.test(navigator.userAgent)?'Mobile':'Desktop';}
async function record(kind:'page_view'|'chat',extra:Record<string,unknown>={}){
 if(!tracingEndpoint||getTracingConsent()!=='allow')return;
 try {
  const visitor_id=identifier(localStorage,visitorKey),session_id=identifier(sessionStorage,sessionKey);
  const geo=await location();
  if(getTracingConsent()!=='allow')return;
  let referrer_host='';try{referrer_host=new URL(document.referrer).hostname;}catch{/* Direct or unavailable. */}
  await fetch(tracingEndpoint,{method:'POST',headers:{'Content-Type':'application/json',...(publicKey?{'Authorization':`Bearer ${publicKey}`,'apikey':publicKey}:{})},body:JSON.stringify({kind,visitor_id,session_id,page_path:window.location.pathname,referrer_host,device:device(),browser:browser(),...geo,...extra}),credentials:'omit',keepalive:true,signal:AbortSignal.timeout(5000)});
 }catch{/* Analytics must never prevent viewing the website or using the chat. */}
}
export function recordPageView(){if(pageLogged||!tracingEndpoint||getTracingConsent()!=='allow')return;pageLogged=true;void record('page_view');}
export function recordChat(question:string,answer:string,link?:{label:string;href:string}){void record('chat',{question:question.slice(0,500),answer:answer.slice(0,16000),answer_link:link?`${link.label}: ${link.href}`:null});}
