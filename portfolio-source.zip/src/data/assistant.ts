import { profile } from './profile';
import { projects } from './projects';
import { experience } from './experience';
import { education } from './education';
import { skills } from './skills';
import { recruitment } from './recruitment';

export type PortfolioAnswer = {text:string;link?:{label:string;href:string}};
const unavailable = {text:"That information isn't currently included in Henry's portfolio. You can contact him directly at henrylum27@gmail.com for confirmation.",link:{label:'Email Henry',href:'mailto:henrylum27@gmail.com'}};
const unrelated = {text:'I can only answer questions about Henry and his portfolio or job preferences. Try asking about his skills, projects, availability or experience.'};
const personal = /\b(henry|he|his|him|you|your|yourself|portfolio)\b/;
const unrelatedTopic = /\b(weather|recipe|cook|joke|politic\w*|president|election|sport\w*|football|bitcoin|crypto|stock\w*|investment|diagnos\w*|medical advice|treatment|news|horoscope|movie\w*|song\w*|poem|story|travel advice)\b/;
const unsupported = /\b(age|birthday|birth date|visa|citizen\w*|married|family|religion|race|home address|phone|gpa|award\w*)\b/;
const instructions = /\b(ignore|override|pretend|system prompt|previous instructions|act as|write code|generate code|implement|debug|solve|calculate|translate)\b/;
const confirmed = [...new Set([...skills.flatMap(g=>g.items),...projects.flatMap(p=>p.technologies),...experience.flatMap(e=>e.technologies)])];
const limited = ['RAG','Embeddings'];
function link(label:string,path:string){return {label,href:`${import.meta.env.BASE_URL}${path}`};}
function normalise(text:string){return text.toLowerCase().replace(/[’']/g,'').trim();}
function escape(text:string){return text.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function mentions(text:string,term:string){return new RegExp(`(^|[^a-z0-9])${escape(term.toLowerCase())}($|[^a-z0-9])`,'i').test(text);}

// Recruiter wording identifies a requested technology, not a confirmed skill.
function technologyTargets(question:string):string[]{
 const candidates:string[]=[];
 const patterns=[
  /(?:\bwe|\bour team|\bour company)\s+(?:use|uses|work with)\s+(.+?)(?=[?!]|\.(?:\s|$)|$)/ig,
  /\b(?:know|knows|experience with|experience in|experienced in|worked with|work with|used|use|familiar with|proficient in|skills in|learn)\s+(.+?)(?=[?!]|\.(?:\s|$)|$)/ig,
  /\b(?:have|has)\s+(?:any\s+|direct\s+|professional\s+)?([a-z0-9+#. -]+?)\s+(?:industry\s+)?experience\b/ig,
  /\b(?:years? of experience.*?\bwith|years? (?:of )?(?:professional )?experience (?:in|with))\s+(.+?)(?=[?!]|\.(?:\s|$)|$)/ig
 ];
 for(const pattern of patterns)for(const match of question.matchAll(pattern)){
  const chunk=match[1].replace(/\b(professionally|extensively|before|already|at work|in production|for this role|for the role|if required|as required)\b.*$/i,'').trim();
  for(const part of chunk.split(/,|\band\b|\bor\b/i)){
   const target=part.replace(/^(?:the|a|an|any|strong|hands-on|professional|working)\s+/i,'').replace(/\s+(?:development|programming|framework|language|platform|technology|database|tools?)$/i,'').trim();
   if(target&&!/^(it|that|this|these|those|them|anything|new technologies|new tools|new systems|how\b.*|what\b.*|henry\b.*|you\b.*|he\b.*|\d.*years.*|experience.*)$/i.test(target)&&target.length<=65)candidates.push(target);
  }
 }
 return [...new Set(candidates.map(t=>confirmed.find(c=>normalise(c)===normalise(t))||t))];
}
function skillAnswer(targets:string[],q:string):PortfolioAnswer{
 const known=targets.filter(t=>confirmed.some(c=>normalise(c)===normalise(t))),unknown=targets.filter(t=>!known.includes(t));
 const professional=/\b(professional\w*|production|commercial|at work|on the job)\b/.test(q),parts:string[]=[];
 if(unknown.length){
  const industry=/\b(industry|sector|banking|finance|retail|manufacturing|insurance|telecom|hospitality)\b/i.test(unknown.join(' '));
  parts.push(industry?`Direct professional experience in ${unknown.join(', ')} is not confirmed in Henry’s portfolio.`:`${unknown.join(', ')} ${unknown.length===1?'is':'are'} not currently listed among Henry’s confirmed hands-on technologies.`);
  if(unknown.some(t=>/django/i.test(t)))parts.push('His backend experience with Python and FastAPI, including REST API integration, provides a foundation for learning another Python framework.');
  else if(unknown.some(t=>/angular/i.test(t)))parts.push('His frontend experience is mainly with React and TypeScript, including component-based interfaces.');
  else if(unknown.some(t=>/postgres|mysql|oracle|mariadb|database/i.test(t)))parts.push('He has worked with SQL, SQLite and Microsoft SQL Server, giving him a foundation in relational databases and SQL workflows.');
  else parts.push('His main experience includes Python, React/TypeScript, FastAPI, APIs, SQL and AI integration.');
  parts.push(`He is open to learning ${unknown.join(', ')} if the role requires it.`);
 }
 if(known.length){
  const concepts=known.filter(t=>limited.includes(t)),practical=known.filter(t=>!concepts.includes(t));
  if(practical.length){
   const internship=practical.filter(t=>experience.some(e=>e.technologies.some(c=>normalise(c)===normalise(t))));
   if(professional){
    if(internship.length)parts.push(`${internship.join(', ')} ${internship.length===1?'is':'are'} supported by his Noetic Synergy internship, where he maintained and validated enterprise data using SQL-supported workflows.`);
    const projectOnly=practical.filter(t=>!internship.includes(t));
    if(projectOnly.length)parts.push(`${projectOnly.join(', ')} ${projectOnly.length===1?'is':'are'} listed in his portfolio skills or project work; extensive professional use is not confirmed. He is willing to expand that experience for the role.`);
   }else {
    const integration=practical.some(t=>/^(react|typescript|fastapi|rest apis|openai api)$/i.test(t));
    const sql=practical.some(t=>/^sql$/i.test(t));
    parts.push(`Yes. ${practical.join(', ')} ${practical.length===1?'is':'are'} included in Henry’s confirmed skills${integration?', including frontend, API integration or reporting work in the original BinaryMed project':sql?', including SQL-supported enterprise data validation at Noetic Synergy':', supported by his portfolio or project experience'}.`);
   }
  }
  if(concepts.length)parts.push(`Henry has some familiarity with ${concepts.join(' and ')} through concepts worked with or studied. He does not claim extensive production experience and is comfortable expanding his knowledge for the role.`);
 }
 return {text:parts.join(' '),link:link('Explore skills','#skills')};
}

export function answerPortfolioQuestion(question:string,previousQuestion=''):PortfolioAnswer{
 const q=normalise(question),previous=normalise(previousQuestion);
 if(!q)return {text:'What would you like to know about Henry?'};
 if(unrelatedTopic.test(q)||instructions.test(q))return unrelated;
 if(/\b(binary\s?med|binarymedai)\b/.test(q)){
  const project=projects.find(p=>p.id==='binarymed')!;
  const context='The current BinaryMed showcase uses sample/mock data and simulated transport. It does not demonstrate live production IoT or clinical certification. Real AI report generation, saved schedules and genuine PDF exports require the backend services; comparison metrics and workflow messages are fixtures.';
  const text=/github|repo/.test(q)?'BinaryMed’s GitHub organisation is BinaryMedAI.':/\b(role|contribut\w*|personally|responsib\w*|did)\b/.test(q)?'Henry mainly worked on the original BinaryMed React/TypeScript frontend components, REST API integration, report generation, testing and connecting frontend and backend services. His reporting work involved Python/FastAPI services and LLM assistance.':/\b(stack|technolog\w*)\b/.test(q)?`The current frontend uses ${project.technologies.join(', ')}. Henry’s original reporting and integration work also involved Python/FastAPI services and LLM assistance.`:/\b(features?|replay|maps?)\b/.test(q)?'BinaryMed’s current frontend demonstrates transport dashboards, replay controls, temperature insights, incident maps and mock report comparisons. Report-generation and scheduling interfaces require backend services for real processing and persistence.':/\b(live|real|clinical|certif\w*|generat\w*|schedule\w*|pdf|limitation\w*|backend)\b/.test(q)?context:'BinaryMed explores medical sample transport monitoring; its current frontend uses sample and simulated data for dashboards, replay, temperature insights and report workflows. Henry mainly worked on the original React/TypeScript frontend, REST API integration, report generation and testing. Real AI generation, PDF exports and saved schedules require the backend services.';
  return {text,link:/github|repo/.test(q)?{label:'BinaryMedAI on GitHub',href:project.github!}:link('Read the BinaryMed case study','projects/binarymed')};
 }
 if(/^(hi|hello|hey|thanks|thank you)[!. ]*$/.test(q))return {text:'Hello! Ask me about Henry’s projects, skills, experience, availability or job preferences.'};
 const salary=/\b(salary|compensation|remuneration|pay|package|rm\s*[\d,]+)\b/.test(q)||(/\b(fixed|negotiable|negotia\w*|accept less|lower|flexible)\b/.test(q)&&/salary|compensation|rm\s*[\d,]+/.test(previous));
 const availability=/\b(availability|available|immediately|start(?:ing)?(?: date)?|begin work|begin immediately|begin when|begin\b.*\bwork|join|notice period)\b/.test(q);
 const relocation=/\b(relocat\w*|another state|another country|another.*country|different state|different country|move.*(?:work|role|country|state))\b/.test(q);
 const shift=/\b(night shift\w*|overnight|shift\w*|working hours|work hours|flexible hours)\b/.test(q);
 const recruiterAnswers:string[]=[];
 if(availability)recruiterAnswers.push(recruitment.start);
 if(relocation)recruiterAnswers.push(recruitment.relocation);
 if(shift)recruiterAnswers.push(recruitment.shifts);
 if(salary){
  if(/\b(current|previous|past|last|earned|earning)\b/.test(q))recruiterAnswers.push('Henry’s current or past salary is not confirmed. His preferred expected salary is around RM3,500 per month and is negotiable.');
  else recruiterAnswers.push(/\b(fixed|negotia\w*|accept|less|lower|minimum|flexib\w*)\b/.test(q)?recruitment.salaryNegotiation:recruitment.salary);
 }
 if(recruiterAnswers.length){
  if(unsupported.test(q))recruiterAnswers.push(/visa/.test(q)?'Visa status is not supplied in his portfolio and would need to be discussed directly with Henry.':'Other personal details not supplied in his portfolio would need to be discussed directly with Henry.');
  if(availability&&relocation&&shift&&!salary&&!unsupported.test(q))return {text:'Henry is available to start anytime. He is also open to relocation for the right opportunity and is willing to work night shifts if the role requires it.'};
  return {text:recruiterAnswers.join(' ')};
 }
 if(unsupported.test(q))return unavailable;
 if(/\baws\b|amazon web services|ai practitioner/.test(q)){
  const certified=/\b(certified|certification|certificate|hold\w*|passed|complete\w*)\b/.test(q)&&!(/\b(study\w*|course|prepar\w*)\b/.test(q));
  const professional=/\b(professional\w*|production|hands-on|hands on|commercial)\b/.test(q);
  const targets=technologyTargets(question).filter(t=>!/^aws(?: certified ai practitioner)?$/i.test(t));
  const text=professional?recruitment.awsProfessional:certified?(recruitment.awsCertified?`Henry holds the ${recruitment.awsCertification} certification.`:'Not yet. Henry is currently preparing for the AWS Certified AI Practitioner exam and plans to take it soon.'):recruitment.awsCourse;
  return {text:targets.length?`${text} ${skillAnswer(targets,q).text}`:text};
 }
 if(/\b(certif\w*|certified|certificate\w*)\b/.test(q))return {text:recruitment.awsCertified?`Henry holds the ${recruitment.awsCertification} certification. No other completed certifications are confirmed.`:'No completed certifications are confirmed in the current portfolio. Henry is currently taking an AWS Certified AI Practitioner course and preparing for the exam; he is not yet AWS certified.'};
 if(/\b(years?|yrs?)\b/.test(q)&&/\b(experience|worked|working|engineering|professional\w*)\b/.test(q)){
  const years=q.match(/\b(?:\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s*\+?\s*(?:years?|yrs?)\b/)?.[0];
  return {text:`${years?`Henry does not claim ${years} of professional experience.`:'A total number of professional years is not confirmed in Henry’s portfolio.'} He is a recent Computer Science graduate specialising in Big Data and Artificial Intelligence, with hands-on project experience including BinaryMed and a Data Entry internship at Noetic Synergy (January–June 2024). He is comfortable learning new tools and developing his experience.`};
 }
 if(/\b(senior engineers?|guidance|mentorship|feedback)\b/.test(q)&&/\b(work|learn|comfortable|under|with|receiv\w*)\b/.test(q))return {text:recruitment.seniorGuidance};
 if(/\b(adapt\w*|new environment|new company|new team|new workflow|different.*(?:industry|stack|team)|work culture|team operates)\b/.test(q))return {text:recruitment.adaptation};
 if(/\b(first.*(?:role|job)|matters most|priorit\w*|learning opportunit\w*|career growth)\b/.test(q))return {text:recruitment.priorities};
 if(/\b(binary\s?med|binarymedai)\b/.test(q)){
  const project=projects.find(p=>p.id==='binarymed')!;
  if(/github|repository|repositories/.test(q))return {text:'BinaryMed’s GitHub organisation is BinaryMedAI.',link:{label:'BinaryMedAI on GitHub',href:project.github!}};
  return {text:/\b(role|contribut\w*|personally|responsib\w*|part|work|did|built)\b/.test(q)?project.contribution:`${project.name}: ${project.description}\n\nHenry’s contribution: ${project.contribution}`,link:link('Read the BinaryMed case study','projects/binarymed')};
 }
 if(/\b(data analyst|data-analyst-agent)\b/.test(q)){const p=projects.find(p=>p.id==='data-analyst-agent')!;return {text:`${p.name}: ${p.description}\n\n${p.contribution}`,link:link('Explore Data Analyst Agent','projects/data-analyst-agent')};}
 const targets=technologyTargets(question);
 if(targets.length)return skillAnswer(targets,q);
 const shortTopic=/^(about|background|skills|education|experience|internship|projects|contact|resume|languages|location|opportunities|github|linkedin)[?!. ]*$/;
 if(!personal.test(q)&&!shortTopic.test(q))return unrelated;
 if(/\b(contact|email|reach|connect|linkedin|github)\b/.test(q))return {text:`Email: ${profile.email}\nGitHub: ${profile.github}\nLinkedIn: ${profile.linkedin||'Not added yet.'}`,link:link('Contact Henry','#contact')};
 if(/\b(resume|cv)\b/.test(q))return profile.resumeAvailable?{text:'Henry’s resume is available to download.',link:link('Download resume',profile.resume)}:{text:'Henry’s resume PDF has not been added yet. You can email him to request it.',link:{label:'Email Henry',href:`mailto:${profile.email}`}};
 if(/\b(education|degree|university|graduat\w*|stud\w*|college|qualification\w*)\b/.test(q))return {text:`${education.degree}, ${education.university}. Specialisation: ${education.specialisation}. Graduation: ${education.graduation}.\n\n${education.pathway}`,link:link('View education','#education')};
 if(/\b(experience|intern\w*|company|companies|job history|worked|workplace)\b/.test(q))return {text:experience.map(e=>`${e.role} at ${e.company}\n${e.dates} · ${e.location}\n${e.description}`).join('\n\n'),link:link('View experience','#experience')};
 if(/\b(language\w*|speak\w*|mandarin|malay|english|chinese)\b/.test(q)&&!(/\b(programming|code|coding)\b/.test(q)))return {text:'English: Advanced\nChinese / Mandarin: Advanced\nMalay: Upper Intermediate',link:link('View languages','#education')};
 const mentioned=confirmed.filter(t=>mentions(q,t));
 if(mentioned.length)return skillAnswer(mentioned,q);
 if(/\b(skill\w*|technolog\w*|stack|programming|code|coding|tool\w*)\b/.test(q))return {text:'Henry’s main toolkit includes Python, SQL, TypeScript, React, FastAPI, REST APIs, data processing and LLM integration. RAG and embeddings are concepts worked with or studied; extensive production experience is not claimed.',link:link('Explore skills','#skills')};
 if(/\b(project\w*|build\w*|built|application\w*)\b/.test(q))return {text:projects.map(p=>`${p.name} — ${p.subtitle}\n${p.description}`).join('\n\n'),link:link('View projects','#projects')};
 if(/\b(location|based|live|living|where|malaysia)\b/.test(q))return {text:'Henry is based in Malaysia. His studies included University of Wollongong Malaysia and University of Wollongong in Australia.'};
 if(/\b(opportunit\w*|looking|seek\w*|role\w*|hire|hiring|interest\w*|career)\b/.test(q))return {text:'Henry is open to graduate and junior opportunities in AI engineering, software development, data and intelligent application development.',link:link('Get in touch','#contact')};
 if(/\b(who|about|background|introduc\w*|title|yourself)\b/.test(q))return {text:`${profile.name} is a Computer Science graduate specialising in Big Data and Artificial Intelligence, based in Malaysia. His portfolio features BinaryMed and Data Analyst Agent, and he is open to graduate and junior opportunities.`,link:link('About Henry','#about')};
 return unavailable;
}

