import { answerPortfolioQuestion, type PortfolioAnswer } from './assistant';
import { profile } from './profile';
import { projects } from './projects';
import { skills } from './skills';
import { experience } from './experience';
import { education } from './education';

export type ChatTurn={role:'assistant'|'user';text:string};
const profileSummary='Henry Lum is a Computer Science graduate specialising in Big Data and Artificial Intelligence. His main technical areas include Python, SQL, React/TypeScript, FastAPI, REST APIs, data processing and AI integration. His original BinaryMed final-year project involved frontend development, API integration and AI-assisted reporting. He is looking for graduate or junior opportunities in AI, software development and data-related roles.';
const experienceSummary='Henry was a Data Entry Intern at Noetic Synergy from January to June 2024. He worked with enterprise data in IFCA, SQL-supported data validation, record correction and system troubleshooting.';
const skillsSummary='Henry’s main technical skills include Python, SQL, JavaScript/TypeScript, React, FastAPI, REST APIs, Pandas, PySpark and AI/LLM integration. He also works with data processing, anomaly detection, Git, GitHub and relational databases.';
const projectSummary='Henry’s projects focus on AI, data and software development. BinaryMed demonstrates transport monitoring interfaces and his original frontend, API integration and reporting work; its current showcase uses simulated data. Data Analyst Agent explores AI-assisted data-analysis workflows.';
const binarySummary='BinaryMed is Henry’s final-year project exploring medical sample transport monitoring. Henry mainly worked on the original React/TypeScript frontend, REST API integration, report generation, testing and connecting services. The current showcase uses sample/simulated data; real AI report generation requires the backend services.';
const conciseProfile='Henry is a Computer Science graduate specialising in Big Data and AI, with hands-on experience in Python, React/TypeScript, FastAPI, APIs, data processing and AI-assisted applications.';
const summaryIntent=/\b(summari[sz]\w*|summary|overview|recap|quick introduction|short version|what should i know|tl;?dr|tldr)\b/i;
const veryShort=/\b(one sentence|very short|tl;?dr|tldr|briefly|one line)\b/i;
const detailIntent=/\b(detailed|everything|full overview|more detail|explain more|tell me more|what exactly|how did .*work|how did that work)\b/i;
function topic(q:string){
 if(/binary\s?med/i.test(q))return 'binarymed';
 if(/data[- ]analyst/i.test(q))return 'data-analyst-agent';
 if(/skill|technolog|toolkit|stack/i.test(q))return 'skills';
 if(/experience|intern|noetic|work history/i.test(q))return 'experience';
 if(/projects?/i.test(q))return 'projects';
 if(/education|degree|university|background/i.test(q))return 'education';
 if(/salary|compensation|pay|package/i.test(q))return 'salary';
 if(/start|available|availability|notice/i.test(q))return 'availability';
 if(/relocat/i.test(q))return 'relocation';
 if(/shift/i.test(q))return 'shifts';
 if(/aws|certif/i.test(q))return 'aws';
 return 'profile';
}
function firstSentence(text:string){return text.split(/(?<=[.!?])\s+/)[0];}
function summaryFor(q:string):PortfolioAnswer{
 const t=topic(q);
 let text=t==='binarymed'?binarySummary:t==='experience'?experienceSummary:t==='skills'?skillsSummary:t==='projects'?projectSummary:t==='data-analyst-agent'?'Data Analyst Agent explores AI-assisted dataset analysis and common analytical workflows. Detailed implementation and Henry’s personal contribution are not yet confirmed in the portfolio.':t==='education'?`Henry holds a ${education.degree} from ${education.university}, specialising in ${education.specialisation}. His study pathway included University of Wollongong Malaysia before continuing in Australia.`:t==='profile'?profileSummary:answerPortfolioQuestion(q).text;
 if(veryShort.test(q))text=t==='profile'?conciseProfile:t==='binarymed'?'BinaryMed explores medical sample transport monitoring with a simulated frontend showcase; Henry’s original contribution covered React/TypeScript, APIs, reports and testing.':t==='projects'?'Henry’s projects include BinaryMed, a medical sample transport monitoring project, and Data Analyst Agent, which explores AI-assisted analysis.':firstSentence(text);
 return {text};
}
function detailed(q:string):PortfolioAnswer{
 const factual=answerPortfolioQuestion(q);
 if(/not currently listed|Direct professional experience.*not confirmed/.test(factual.text))return factual;
 const t=topic(q);
 if(t==='binarymed')return {text:`Overview\n${binarySummary}\n\nHenry’s contribution\n${projects[0].contribution}\n\nCurrent frontend\n${projects[0].features.join('; ')}. React/TypeScript, Vite, charts, maps and service-layer integration support the views.\n\nDemo boundaries\nDetailed pages use independent sample datasets. Comparison metrics and workflow messages are fixtures; real AI generation, saved schedules and genuine PDF exports require backend services.`,link:{label:'Read the BinaryMed case study',href:`${import.meta.env.BASE_URL}projects/binarymed`}};
 if(t==='experience')return {text:experience.map(e=>`${e.role} — ${e.company}\n${e.dates}\n${e.description}\n\n${e.responsibilities.map(r=>`• ${r}`).join('\n')}`).join('\n\n')};
 if(t==='skills')return {text:skills.map(g=>`${g.name}\n${g.items.join(', ')}`).join('\n\n')+'\n\nRAG and embeddings are concepts worked with or studied; extensive production experience is not claimed.'};
 if(t!=='profile'&&t!=='education'&&t!=='projects')return answerPortfolioQuestion(q);
 return {text:`Background\n${education.degree}, ${education.university}; ${education.specialisation}.\n\nExperience\n${experienceSummary}\n\nProjects\n${projectSummary}\n\nSkills\n${skillsSummary}\n\nCareer Interests\nGraduate or junior opportunities in AI engineering, software development and data.`};
}

export function answerPortfolioChat(question:string,history:ChatTurn[]=[]):PortfolioAnswer{
 const q=question.trim();
 const lastUser=history.filter(m=>m.role==='user'&&!/^(?:can you |could you |please )?(?:explain more|tell me more|give me more detail|what exactly did he do|how did that work)[?.! ]*$/i.test(m.text)).at(-1)?.text;
 const previous=history.slice(-2).map(m=>m.text).join(' ');
 // Summary/detail requests never bypass the factual engine's topic and instruction guards.
 if(/\b(ignore|override|pretend|system prompt|previous instructions|act as|write code|generate code|implement|debug|solve|calculate|translate|weather|recipe|cook|joke|politic\w*|president|election|sport\w*|football|bitcoin|crypto|stock\w*|investment|diagnos\w*|medical advice|treatment|news|horoscope|movie\w*|song\w*|poem|story|travel advice)\b/i.test(q))return answerPortfolioQuestion(q,previous);
 if(/\b(phone|mobile|contact number|telephone|call henry)\b/i.test(q))return {text:`You can contact Henry at ${profile.phone} or ${profile.email}.`,link:{label:'Call Henry',href:profile.phoneHref}};
 if(/\b(visa|work permit|citizen\w*|personal information|birthday|home address|gpa|radical control|assistant project engineer)\b/i.test(q))return {text:"That information isn't currently included in Henry's portfolio. You can contact him directly at henrylum27@gmail.com for confirmation.",link:{label:'Email Henry',href:`mailto:${profile.email}`}};
 const specificSkill=q.match(/\b(Django|Angular|Azure|Kubernetes|PostgreSQL|TensorFlow|PyTorch)\b|C#|\.NET/i)?.[0];
 if(specificSkill&&(summaryIntent.test(q)||detailIntent.test(q)||veryShort.test(q)))return answerPortfolioQuestion(`Does Henry know ${specificSkill}?`);
 const followup=/^(?:can you |could you |please )?(?:explain more|tell me more|give me more detail|what exactly did he do|how did that work)[?.! ]*$/i.test(q);
 if(followup)return lastUser?detailed(lastUser):{text:'Which part of Henry’s portfolio would you like more detail about—his projects, skills or experience?'};
 const recap=summaryIntent.test(q)&&topic(q)==='profile'&&history.some(m=>m.role==='user')&&!/\b(overall|profile|background|introduction|everything|full overview)\b/i.test(q);
 if(recap){
  const userQuestions=history.filter(m=>m.role==='user').map(m=>m.text).filter(text=>!summaryIntent.test(text)&&!/^(?:can you |please )?(?:explain more|tell me more|give me more detail)[?.! ]*$/i.test(text));
  const selected=[...new Map(userQuestions.map(text=>[topic(text),text])).values()].slice(-4);
  if(selected.length)return {text:selected.map(text=>{
   const t=topic(text);
   if(t==='profile')return firstSentence(answerPortfolioQuestion(text).text);
   return firstSentence(summaryFor(text).text);
  }).join(' ')};
 }
 if(detailIntent.test(q))return detailed(q);
 if(/\b(all|complete|every|full list)\b/i.test(q)&&/\b(skill|skills|technologies|toolkit)\b/i.test(q))return detailed('skills');
 if(/\b(all|every|complete list)\b/i.test(q)&&/projects?/i.test(q))return {text:projects.map(p=>`• ${p.name}: ${p.id==='binarymed'?'Medical sample transport monitoring with a current sample/simulated frontend showcase.':'Explores AI-assisted data-analysis workflows.'}`).join('\n')};
 if(summaryIntent.test(q)||veryShort.test(q))return summaryFor(q);
 if(/\b(who is henry|about henry|introduce henry|what should i know about henry)\b/i.test(q))return summaryFor(q);
 return answerPortfolioQuestion(q,previous);
}

