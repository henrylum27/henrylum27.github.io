// Facts and preferences supplied by Henry; update these when circumstances change.
export const recruitment = {
 start:'Henry is available to start anytime and is ready to begin when the opportunity is available.',
 relocation:'Yes. Henry is willing to relocate for the right opportunity and is open to discussing the location requirements of the role.',
 shifts:'Yes. Henry is willing to work night shifts if the role requires it and is flexible with working hours.',
 salary:'Henry’s preferred expected salary is around RM3,500 per month, but this is negotiable. At this stage of his career, he also places strong importance on the learning opportunities, exposure and experience the company can provide.',
 salaryNegotiation:'RM3,500 is Henry’s preferred starting salary, but he is open to discussing the overall package. The role, responsibilities, learning opportunities, exposure to real projects, mentorship and potential for growth are also important factors for him.',
 priorities:'Henry is looking for a role where he can build strong practical experience, learn from experienced team members, work on meaningful technical projects and continue developing his AI and software engineering skills.',
 awsCourse:'Henry is currently taking an AWS Certified AI Practitioner course and is preparing to take the certification exam soon.',
 awsCertified:false,
 awsCertification:'AWS Certified AI Practitioner',
 awsProfessional:'Henry is currently building his AWS knowledge through his AWS AI Practitioner studies. He does not claim extensive professional AWS experience yet, but he is actively learning the platform.',
 adaptation:'Yes. Henry is comfortable adapting to new working environments and learning how a team operates. He is open to feedback, willing to learn unfamiliar tools and understands that different companies have different development processes and working practices.',
 seniorGuidance:'Henry is comfortable working under the guidance of senior engineers, receiving feedback, asking questions when necessary and learning the team’s development practices.'
};
