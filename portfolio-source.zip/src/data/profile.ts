export const profile = {name:'Henry Lum Wei Han',title:'AI & Software Engineer',email:'henrylum27@gmail.com',phone:'+6018-6620531',phoneHref:'tel:+60186620531',github:'https://github.com/henrylum27',linkedin:'https://www.linkedin.com/in/henry-wei-han-lum-a52491308' as string|null,resume:'resume/Henry_Lum_Resume.pdf',resumeAvailable:false};


