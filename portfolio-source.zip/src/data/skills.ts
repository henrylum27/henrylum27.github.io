export const skills = [
{name:'Programming & Data',items:['Python','SQL','JavaScript','TypeScript','PySpark','Pandas','NumPy']},
{name:'AI & Machine Learning',items:['Machine Learning','Anomaly Detection','OpenAI API','LLM Integration','Prompt Engineering','Model Evaluation','AI Agents']},
{name:'Generative AI Concepts',note:'Worked with or studied; no claim of expert production experience.',items:['RAG','Embeddings','AI Agents','LLM Applications']},
{name:'Backend & Integration',items:['FastAPI','REST APIs','API Integration']},
{name:'Frontend',items:['React','TypeScript','HTML','CSS']},
{name:'Big Data & Data Engineering',items:['Apache Spark','PySpark','Data Processing','Data Cleaning','Data Validation','Data Transformation','Relational Databases']},
{name:'Databases',items:['SQL','SQLite','Microsoft SQL Server']},
{name:'Development Tools',items:['Git','GitHub','Testing','Debugging','Documentation']},
{name:'Additional Technical Tools',items:['Grafana','MQTT','VMware']}
];
