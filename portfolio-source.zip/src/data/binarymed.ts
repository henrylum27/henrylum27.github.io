export const binarymedStudy = {
  context:'Originally an industry-sponsored final-year project. The sponsor connection is no longer active; the current portfolio showcase is a standalone frontend demonstration.',
  overview:'BinaryMed demonstrates how transport readings, warning events, journey information and report records can be brought together in a medical sample monitoring interface. The current frontend uses repository sample/mock datasets and three explicitly simulated transport scenarios.',
  problem:'Transport readings can be difficult to interpret in isolation. Reviewing temperature changes alongside journey progress and timestamped warnings helps explain what happened during a sample’s transport. BinaryMed explores an interface for that review, without making a clinical suitability decision.',
  solution:'A React interface combines a transport dashboard, replay controls, temperature analysis, incident maps and example report comparisons. Search and filtering help users explore the existing datasets. Report generation and recurring schedules have configuration interfaces, while actual processing and persistence require the backend services.',
  features:[
    {title:'Transport dashboard',detail:'Recorded temperature, operational compliance, anomaly count and severity, journey progress, temperature statistics, checkpoints, activity timeline and a local dataset report summary.'},
    {title:'Three scenarios & replay',detail:'Normal transport, temperature excursion and minor fluctuation. Play, pause, restart, a position slider and 1× / 2× / 4× speeds update readings, journey progress and anomaly/compliance state.'},
    {title:'Temperature Insights',detail:'Temperature history, warning breakdowns, search, severity/date filtering, a paginated incident table and export controls. The date range starts at January 1, 2024 to include the example records.'},
    {title:'Geographic incident review',detail:'A Leaflet map with category, severity and date filtering, suburb rankings and location drill-down into individual mock incidents.'},
    {title:'Example report comparison',detail:'Two report selectors lead to overview, temperature, orientation, openings, path, alerts and trends tabs. The comparison metrics and recommendations are mock fixtures.'},
    {title:'Report & scheduling interfaces',detail:'Report search/status filters, metadata, an illustrative generation timeline, a generation request form, a calendar and recurring schedule configuration. Generation and schedule writes require backend services.'}
  ],
  architecture:[
    {title:'Sample & simulated data',detail:'Dashboard scenarios and independent fixtures for the detailed pages.'},
    {title:'Data adapter & service layer',detail:'Separates view components from demo fixtures and integration interfaces.'},
    {title:'React frontend',detail:'Routes, filters, replay controls and interface state.'},
    {title:'Charts, maps & local summaries',detail:'Chart.js / Recharts visualisations, Leaflet maps and dataset previews.'}
  ],
  backend:'Real AI report generation, saved recurring schedules and genuine report/comparison PDF exports require the BinaryMed Web Backend/orchestrator, ADM analysis engine, PDF service and configured storage/data sources.',
  limitations:[
    'Detailed pages have independent datasets. Selecting a dashboard scenario does not filter the temperature, map or comparison pages.',
    'The dashboard uses mock 20–25°C thresholds for an operational demo. These are not clinical rules, certification or a medical suitability verdict.',
    'Comparison metrics and AI/PDF workflow messages in report status are fixtures, not evidence that fresh AI analysis or a report-generation workflow ran.',
    'Local dataset previews summarise the selected scenario. Existing report-detail charts, KPIs and recommendations include unfinished placeholders.',
    'No generation or scheduling writes were submitted while capturing these screenshots. The showcase does not demonstrate live production IoT monitoring.'
  ]
};
