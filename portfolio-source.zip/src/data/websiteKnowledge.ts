import { projects } from './projects';
import { profile } from './profile';
import { education } from './education';
import { experience } from './experience';
import type { PortfolioAnswer } from './assistant';
const base=import.meta.env.BASE_URL;
export const analystSummary='Data Analyst Agent combines CSV uploads, Pandas data checks, local AI report drafting and question-to-SQL analysis with DuckDB. Henry connected the React frontend to FastAPI and integrated Ollama with Llama 3.2 for reports and SQL. The Zomato walkthrough includes six screens and a complete two-page AI report that visitors can preview, open or download.';
export const binarySummary='BinaryMed was Henry’s industry-sponsored final-year project with a team of 6. His contribution focused on React/TypeScript frontend components, FastAPI and REST API integration, report generation with the OpenAI API, testing and connecting services. The current portfolio uses historical or mock data.';
export function projectTopic(q:string):string|undefined{
 if(/binary\s?med|binarymedai/i.test(q))return 'binarymed';
 if(/data[ -]analyst[ -]agent|zomato|duckdb|ollama|llama\s*3/i.test(q))return 'data-analyst-agent';
 return undefined;
}
export function websiteAnswer(question:string,context=''):PortfolioAnswer|undefined{
 const q=question.toLowerCase();
 if(/binary\s?med/.test(q)&&/data[ -]analyst[ -]agent/.test(q)&&/compare|difference|both|versus| vs /.test(q))return {text:'BinaryMed was an industry-sponsored team project with 6 members, focused on medical sample transport; Henry worked on frontend, API integration and OpenAI-assisted reports. Data Analyst Agent is a CSV analysis project using Pandas, local Ollama/Llama 3.2, DuckDB and PDF exports. BinaryMed’s current showcase uses mock data; the agent walkthrough documents a local Zomato run.',link:{label:'View both projects',href:`${base}#projects`}};
 const id=projectTopic(q)||(/\b(report|pdf|dataset|csv|screenshots?|dashboard|replay|ai|model|tools?|built|work|features?|purpose|target|why|how|cost|paid|free|team|contribution|members?)\b/.test(q)?projectTopic(context):undefined);
 if(id){
  const p=projects.find(p=>p.id===id)!;
  const detail=/detailed|everything|full overview|more detail|explain more|tell me more/i.test(q);
  const link={label:`Explore ${p.name}`,href:`${base}projects/${id}`};
  if(/github|repos?\b|repository/.test(q))return {text:`${p.name} source code is available on GitHub.`,link:{label:id==='binarymed'?'BinaryMedAI on GitHub':'Data Analyst Agent on GitHub',href:p.github!}};
  if(id==='data-analyst-agent'){
   if(/report|pdf|download|preview/.test(q))return {text:'The AI report combines Pandas-calculated facts with suggestions drafted locally by Llama 3.2 through Ollama. The complete Zomato report has 2 pages. On the project page, choose Zomato walkthrough → AI report to scroll through both pages, or open or download the PDF.',link:{label:'Open the full Zomato report PDF',href:`${base}data-analyst-zomato-report.pdf`}};
   if(/missing|rows|columns|size|records|how many|dataset|zomato/.test(q))return {text:'The walkthrough uses the Zomato Restaurant Dataset: 9,551 rows, 21 columns and 9 missing Cuisines values (about 0.09% of rows). The city query returned New Delhi with 5,473 restaurants, Gurgaon with 1,118 and Noida with 1,080. Numeric outlier flags need context; they are not confirmed errors.',link};
   if(/openai|ollama|llama|model|\bai\b|paid|cost|free|api key/.test(q))return {text:'Data Analyst Agent uses Llama 3.2 locally through Ollama. The model drafts report suggestions and translates questions into SQL; Pandas calculates the profile and DuckDB executes the query. This setup does not require a paid external AI API. AI text and generated SQL still need review.',link};
   if(/how|workflow|sql|question|query/.test(q))return {text:'React sends the CSV and question to FastAPI. Pandas profiles the file and Python flags unusual numeric values. Ollama proposes SQL using the column names; DuckDB runs the checked query and returns a result table. A separate reporting flow combines calculated facts with AI suggestions and exports a PDF.',link};
   if(/why|tools|stack|technolog/.test(q))return {text:'React/Vite provides the interface; FastAPI connects it to Python; Pandas calculates data checks; Ollama/Llama 3.2 supplies local AI; DuckDB queries CSV data without a separate database server; html2pdf.js exports the report.',link};
   if(/features|screens|presentation/.test(q))return {text:`The six walkthrough screens cover upload and overview, data preview, column checks, numeric outliers, the complete AI report and a question with SQL results. The presentation also explains the goal, Henry’s contribution, workflow, AI integration and tool choices.`,link};
   if(/contribut|role|personally|responsib|did henry/.test(q))return {text:p.contribution,link};
   if(/live|try|run|demo/.test(q))return {text:'The portfolio presents screenshots and a report from a local Zomato run. To use the application yourself, run the frontend, backend and Ollama following its repository instructions. There is no hosted interactive agent linked from the portfolio.',link};
   if(/goal|purpose|target|for whom/.test(q))return {text:'The goal is to bring CSV inspection, data questions and report drafting into one interface, helping users review evidence before deciding what to analyse next.',link};
   return {text:detail?`${analystSummary}\n\nHenry’s contribution: ${p.contribution}\n\nFeatures: ${p.features.join(', ')}.\n\nTools: ${p.technologies.join(', ')}. This is a local project prototype; model output and statistical flags need review.`:analystSummary,link};
  }
  if(/team|alone|individual|sponsor|how many/.test(q))return {text:'BinaryMed was built by a team of 6 with an industry sponsor. Henry did not build the whole system alone. His main responsibilities were frontend development, API integration, report generation, OpenAI integration, testing and connecting application components.',link};
  if(/\bai\b|openai|model|report/.test(q))return {text:'Henry integrated the OpenAI API into the original BinaryMed report generation flow, connecting reporting with frontend and FastAPI services. He worked with API responses, tested generated reports and troubleshot incorrect data. The current portfolio uses example report records; fresh AI reports require backend services and a configured API connection.',link};
  if(/role|contribut|personally|responsib|did/.test(q))return {text:binarySummary,link};
  if(/why|tools|stack|technolog|built|how/.test(q))return {text:'The team used React/TypeScript for the frontend and Python/FastAPI with REST APIs for backend connections. Charts and maps make readings and locations easier to review. Henry’s original OpenAI API integration helped draft report content from transport findings. The system flow is sensor readings → backend processing and checks → frontend review and reports.',link};
  if(/goal|purpose|target|for whom/.test(q))return {text:'BinaryMed was designed to help users review medical sample transport conditions: temperature monitoring, anomaly detection, transport tracking, compliance checking and AI-assisted reports. These describe the team’s system, not features all built by Henry alone.',link};
  if(/screens|presentation|dashboard|replay|map|features/.test(q))return {text:`The dashboard tour covers transport monitoring, scenario replay, Temperature Insights, an incident map, report comparison and a report library. The seven presentation chapters explain the goal, Henry’s contribution, the screens, how it was built, AI integration, tool choices and GitHub. ${p.description}`,link};
  return undefined;
 }
 if(/\b(contact|phone|mobile|telephone|email|linkedin)\b/.test(q))return {text:`Phone: ${profile.phone}\nEmail: ${profile.email}\nLinkedIn: ${profile.linkedin}\nGitHub: ${profile.github}`,link:{label:'Contact Henry',href:`${base}#contact`}};
 if(/\b(education|studied|study|degree|university|college|kdu|foundation|pre u|pre-university)\b/.test(q))return {text:`${education.degree}, ${education.university}, Australia; ${education.specialisation}, class of ${education.graduation}.\n\n${education.pathway}`,link:{label:'View education',href:`${base}#education`}};
 const job=experience.find(e=>q.includes(e.company.toLowerCase())||(/shabuyo|shabu-?yo/.test(q)&&e.company==='Shabuyo'));
 if(job)return {text:`${job.role} at ${job.company}\n${job.dates} · ${job.location}\n${job.responsibilities.join(' ')}`,link:{label:'View experience',href:`${base}#experience`}};
 if(/\b(resume|cv)\b/.test(q))return {text:'Henry’s resume is available using the Resume button in the navigation or Download Resume in the introduction and contact sections.',link:{label:'Download resume',href:`${base}${profile.resume}`}};
 if(/\b(career|job|roles?)\b/.test(q)&&/interest|looking|seek|target|want|main/.test(q))return {text:`Henry is interested in graduate or junior roles as an ${profile.targetRoles.join(', ')}.`,link:{label:'Contact Henry',href:`${base}#contact`}};
 return undefined;
}

