export const education = {university:'University of Wollongong',degree:'Bachelor of Computer Science',specialisation:'Big Data and Artificial Intelligence',graduation:'2026',location:'Wollongong, Australia',description:'Coursework and projects covered big data processing, artificial intelligence, machine learning, software development, data analysis and distributed data processing.',pathway:'Before studying in Australia, Henry studied Bachelor of Computer Science, majoring in Data Science, at UOW Malaysia KDU from January 2022 to June 2024. Before that, he studied Foundation in Science and Technology at Sunway College from January to December 2021.',technologies:['Apache Spark','PySpark','Machine Learning','Data Processing','Software Development']};

export const earlierEducation = [
 {university:'UOW Malaysia KDU',degree:'Bachelor of Computer Science',specialisation:'Majoring in Data Science',dates:'January 2022 – June 2024',description:'Studied Computer Science before continuing my degree in Australia.'},
 {university:'Sunway College',degree:'Foundation in Science and Technology',specialisation:'Pre-university studies',dates:'January 2021 – December 2021',description:'Studied a pre-university foundation before starting my degree.'},
];

