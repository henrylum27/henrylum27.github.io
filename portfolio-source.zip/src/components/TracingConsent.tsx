import { useEffect,useState } from 'react';
import { getTracingConsent,recordPageView,setTracingConsent,tracingEndpoint } from '../lib/tracing';
export default function TracingConsent(){
 const [consent,setConsent]=useState(getTracingConsent);
 const [settings,setSettings]=useState(false);
 useEffect(()=>{const update=()=>{setConsent(getTracingConsent());recordPageView();};update();window.addEventListener('tracing-consent',update);return()=>window.removeEventListener('tracing-consent',update);},[]);
 if(!tracingEndpoint)return null;
 const choose=(value:'allow'|'decline')=>{setTracingConsent(value);setSettings(false);};
 return <div className="tracing-consent">{consent===null||settings?<section role="dialog" aria-label="Privacy choices"><strong>Privacy choices</strong><p>With your permission, Henry records page visits, approximate location, device and browser, referral source, and chatbot questions and replies. Only Henry can view these records. Supabase stores them, and GeoJS estimates location from your IP address. You can use the site and chatbot without recording. Please avoid sharing sensitive information in chat.</p><div className="button-row"><button className="button primary" onClick={()=>choose('allow')}>Allow recording</button><button className="button secondary" onClick={()=>choose('decline')}>Decline</button></div></section>:<button className="text-link" onClick={()=>setSettings(true)}>Privacy choices</button>}</div>;
}
