import { ArrowLeft, ArrowUpRight, Github } from 'lucide-react';
import { projects } from '../data/projects';
import { Screenshot, Tags, base } from './UI';

const sections=['Overview','What I Worked On','How It Works','Key Features','Technologies','Demo / GitHub'];
const sectionId=(title:string)=>title.toLowerCase().replaceAll(/[^a-z]+/g,'-');

export default function RecruiterProjectDetails({id}:{id:'binarymed'|'data-analyst-agent'}){
 const binary=id==='binarymed';
 const project=projects.find(p=>p.id===id)!;
 const contributions=binary?[
  'Built and updated parts of the React frontend',
  'Connected the frontend to FastAPI backend services',
  'Worked with REST API responses',
  'Worked on the report generation flow',
  'Integrated the OpenAI API for AI-assisted reports',
  'Tested and troubleshot incorrect data, API responses and generated reports',
  'Worked with the team to connect different parts of the application',
 ]:[
  'Built the React interface for CSV uploads, data previews and results',
  'Used Python and Pandas to check missing values and unusual numbers',
  'Connected the FastAPI backend to a local AI model through Ollama for summaries',
  'Worked on turning data questions into SQL and running queries with DuckDB',
  'Added PDF downloads for the generated summary',
 ];
 const features=binary?['Temperature monitoring','Anomaly detection','Transport tracking','Compliance checking','AI-assisted report generation']:['CSV upload and preview','Missing-value and outlier checks','AI-generated summaries','Questions about your data','PDF report downloads'];
 const technologies=binary?['React','TypeScript','Python','FastAPI','REST APIs','OpenAI API','IoT Data']:['React','Python','Pandas','FastAPI','DuckDB','Ollama','Llama 3.2','html2pdf.js'];
 return <div className="container case-study">
  <a className="back-link" href={`${base}#projects`}><ArrowLeft size={17}/>Back to selected work</a>
  <header className="case-hero"><p className="eyebrow">{binary?'FINAL-YEAR TEAM PROJECT':'PERSONAL PROJECT'}</p><h1>{project.name}<span className="accent">.</span></h1></header>
  <div className="case-columns"><aside className="case-index"><span className="mono">ON THIS PAGE</span>{sections.map(title=><a key={title} href={`#${sectionId(title)}`}>{title}</a>)}</aside><div className="case-content">
   <section id="overview"><h2>Overview</h2>{binary?<><p>BinaryMed was my final-year project, built by a team of 6 people together with an industry sponsor. We developed a system to monitor medical samples during transportation using IoT sensor data.</p><p className="muted"><strong>Team Size:</strong> 6 members</p></>:<p>Data Analyst Agent is a project that explores how AI can help users work with datasets. The main idea is to combine Python-based data processing with an AI agent to help with common analysis tasks.</p>}</section>
   <section id="what-i-worked-on"><h2>What I Worked On</h2><p>{binary?'My main contribution focused on the frontend, API integration and report generation. My main responsibilities in the team were:':'I worked on the upload, analysis and reporting flow:'}</p><ul>{contributions.map(point=><li key={point}>{point}</li>)}</ul></section>
   <section id="how-it-works"><h2>How It Works</h2>{binary?<p>IoT sensors collect readings during transport. The backend processes them and checks for unusual behaviour or compliance issues. Users can review temperature data, transport information and generated reports in the frontend.</p>:<p>Users upload a CSV file, and Python checks the dataset. A local AI model can turn those checks into a summary or translate a question into SQL. The system runs the query against the uploaded data and shows the results in the interface.</p>}</section>
   <section id="key-features"><h2>Key Features</h2>{binary&&<p className="muted">Features of the system we developed as a team:</p>}<ul className="feature-list">{features.map(feature=><li key={feature}>{feature}</li>)}</ul></section>
   <section id="technologies"><h2>Technologies</h2><Tags items={technologies}/></section>
   <section id="demo-github"><h2>Demo / GitHub</h2>{binary?<p>The project is no longer connected to the original industry sponsor, so the portfolio version uses historical or mock data to demonstrate how the system works. The screenshots show the frontend; live AI reports and PDF exports need the backend services.</p>:<p>The project runs locally with its backend and Ollama. The repository includes setup instructions and a sample CSV to try it.</p>}<a className="button secondary" href={binary?'https://github.com/BinaryMedAI':'https://github.com/henrylum27/Data-Analyst-Agent'} target="_blank" rel="noreferrer"><Github size={17}/>View GitHub<ArrowUpRight size={15}/></a>{binary&&<details style={{marginTop:'24px'}}><summary className="text-link" style={{cursor:'pointer'}}>View screenshots</summary><div className="binary-gallery" style={{marginTop:'20px'}}>{project.screenshots.map(s=><figure key={s.path}><a href={`${base}${s.path}`} target="_blank" rel="noreferrer" aria-label={`Open ${s.name} screenshot`}><Screenshot project={project.name} {...s}/></a><figcaption><h3>{s.name}</h3></figcaption></figure>)}</div></details>}</section>
  </div></div><div className="case-bottom"><a href={`${base}#projects`} className="button primary"><ArrowLeft size={17}/>All projects</a></div>
 </div>;
}
