import RecruiterProjectDetails from './RecruiterProjectDetails';
export default function BinaryMedCaseStudy(){return <RecruiterProjectDetails id="binarymed"/>;}
