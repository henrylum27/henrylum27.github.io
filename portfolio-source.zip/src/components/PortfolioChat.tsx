import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, MessageCircle, Send, X, RotateCcw, Sparkles } from 'lucide-react';
import { type PortfolioAnswer } from '../data/assistant';
import { answerPortfolioChat } from '../data/chatResponses';

type Message = PortfolioAnswer & {id:number;role:'assistant'|'user'};
const greeting:Message={id:0,role:'assistant',text:'Hi! I’m Henry’s portfolio guide. I can answer questions about his background, projects, skills and experience. What would you like to know?'};
const suggestions=['What did Henry do on BinaryMed?','What are his skills?','When can Henry start?','What is his expected salary?','Is Henry AWS certified?'];

export default function PortfolioChat(){
  const [open,setOpen]=useState(false);
  const [question,setQuestion]=useState('');
  const [messages,setMessages]=useState<Message[]>([greeting]);
  const input=useRef<HTMLInputElement>(null);
  const launcher=useRef<HTMLButtonElement>(null);
  const log=useRef<HTMLDivElement>(null);
  useEffect(()=>{if(open)input.current?.focus()},[open]);
  useEffect(()=>{if(open&&log.current)log.current.scrollTop=log.current.scrollHeight},[messages,open]);
  function close(){setOpen(false);launcher.current?.focus()}
  function send(value:string){const text=value.trim();if(!text)return;const answer=answerPortfolioChat(text,messages);setMessages(previous=>[...previous,{id:Date.now(),role:'user',text},{id:Date.now()+1,role:'assistant',...answer}]);setQuestion('');input.current?.focus()}
  return <div className="portfolio-chat">
    {open&&<section className="chat-panel" role="dialog" aria-label="Ask about Henry" onKeyDown={e=>{if(e.key==='Escape')close()}}>
      <header className="chat-header"><div className="chat-avatar"><Sparkles size={19}/></div><div><h2>Ask about Henry</h2><p>Portfolio facts · Personal guide</p></div><button className="chat-icon" onClick={()=>setMessages([greeting])} aria-label="Reset conversation"><RotateCcw size={16}/></button><button className="chat-icon" onClick={close} aria-label="Close chat"><X size={19}/></button></header>
      <div className="chat-messages" ref={log} role="log" aria-live="polite" aria-relevant="additions" aria-label="Conversation">{messages.map(m=><div key={m.id} className={`chat-message ${m.role}`}><span className="sr-only">{m.role==='user'?'You':'Portfolio guide'}: </span><p>{m.text}</p>{m.link&&<a href={m.link.href} onClick={close}>{m.link.label}<ArrowUpRight size={13}/></a>}</div>)}</div>
      {messages.length===1&&<div className="chat-suggestions" aria-label="Suggested questions">{suggestions.map(s=><button key={s} onClick={()=>send(s)}>{s}<ArrowUpRight size={12}/></button>)}</div>}
      <form className="chat-form" onSubmit={e=>{e.preventDefault();send(question)}}><label className="sr-only" htmlFor="portfolio-question">Question about Henry</label><input ref={input} id="portfolio-question" value={question} onChange={e=>setQuestion(e.target.value)} maxLength={500} placeholder="Ask about Henry…" autoComplete="off"/><button type="submit" disabled={!question.trim()} aria-label="Send question"><Send size={17}/></button></form>
      <p className="chat-note">Answers use saved portfolio facts. No messages are sent or saved.</p>
    </section>}
    <button ref={launcher} className="chat-launcher" aria-expanded={open} aria-label={open?'Close portfolio chat':'Ask about Henry'} onClick={()=>open?close():setOpen(true)}>{open?<X size={20}/>:<MessageCircle size={20}/>}<span>{open?'Close':'Ask about Henry'}</span><span className="status-dot"/></button>
  </div>
}


